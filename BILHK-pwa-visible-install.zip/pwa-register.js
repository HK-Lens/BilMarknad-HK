(() => {
  const APP_NAME = "BILHK";
  const SERVICE_WORKER_URL = "./service-worker.js";
  let deferredPrompt = null;
  let floatingButton = null;
  let modal = null;

  function isStandalone() {
    return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  }

  function ensureStyles() {
    if (document.getElementById("bilhk-pwa-install-style")) return;

    const style = document.createElement("style");
    style.id = "bilhk-pwa-install-style";
    style.textContent = `
      .bilhk-pwa-floating-install {
        position: fixed;
        right: 18px;
        bottom: calc(18px + env(safe-area-inset-bottom));
        z-index: 99999;
        border: 0;
        border-radius: 999px;
        padding: 13px 18px;
        background: linear-gradient(135deg, #f58220, #ffad55);
        color: #fff;
        box-shadow: 0 18px 40px rgba(245,130,32,.32);
        font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        font-size: 14px;
        font-weight: 950;
        display: inline-flex;
        align-items: center;
        gap: 9px;
        cursor: pointer;
      }
      .bilhk-pwa-floating-install:hover { transform: translateY(-2px); }
      .bilhk-pwa-modal {
        position: fixed;
        inset: 0;
        z-index: 100000;
        display: none;
        place-items: center;
        padding: 20px;
        background: rgba(15,23,42,.48);
        backdrop-filter: blur(10px);
      }
      .bilhk-pwa-modal.show { display: grid; }
      .bilhk-pwa-card {
        width: min(460px, 100%);
        border-radius: 28px;
        background: #fff;
        color: #0f172a;
        box-shadow: 0 30px 90px rgba(15,23,42,.30);
        padding: 24px;
        font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }
      .bilhk-pwa-icon {
        width: 54px;
        height: 54px;
        border-radius: 18px;
        display: grid;
        place-items: center;
        margin-bottom: 14px;
        background: rgba(245,130,32,.12);
        color: #f58220;
        font-size: 22px;
      }
      .bilhk-pwa-card h3 {
        margin: 0 0 8px;
        font-size: 21px;
        font-weight: 950;
        letter-spacing: -.04em;
      }
      .bilhk-pwa-card p {
        margin: 0 0 12px;
        color: #64748b;
        font-size: 14px;
        font-weight: 650;
        line-height: 1.75;
      }
      .bilhk-pwa-card ol {
        margin: 12px 0 18px;
        padding-left: 22px;
        color: #334155;
        font-size: 14px;
        line-height: 1.85;
        font-weight: 750;
      }
      .bilhk-pwa-actions {
        display: grid;
        grid-template-columns: 1fr;
        gap: 10px;
      }
      .bilhk-pwa-actions button {
        min-height: 45px;
        border: 0;
        border-radius: 999px;
        font-weight: 950;
        cursor: pointer;
      }
      .bilhk-pwa-close { background: #0f172a; color: #fff; }
      @media (max-width: 520px) {
        .bilhk-pwa-floating-install {
          right: 12px;
          left: 12px;
          bottom: calc(12px + env(safe-area-inset-bottom));
          justify-content: center;
        }
      }
    `;
    document.head.appendChild(style);
  }

  function ensureModal() {
    if (modal) return modal;
    ensureStyles();

    modal = document.createElement("div");
    modal.className = "bilhk-pwa-modal";
    modal.innerHTML = `
      <div class="bilhk-pwa-card" role="dialog" aria-modal="true" aria-labelledby="bilhkPwaTitle">
        <div class="bilhk-pwa-icon"><i class="fa-solid fa-mobile-screen-button"></i></div>
        <h3 id="bilhkPwaTitle">Installera BILHK som app</h3>
        <p>Om installationsfönstret inte öppnas automatiskt betyder det att Chrome ännu inte har aktiverat PWA-installationen för sidan.</p>
        <ol>
          <li>Öppna sidan i Chrome på Android.</li>
          <li>Tryck på menyn ⋮ uppe till höger.</li>
          <li>Välj <strong>Install app</strong> eller <strong>Add to Home screen</strong>.</li>
          <li>Om valet inte syns: ladda om sidan efter att manifest och service-worker har publicerats.</li>
        </ol>
        <div class="bilhk-pwa-actions">
          <button type="button" class="bilhk-pwa-close">Stäng</button>
        </div>
      </div>
    `;

    modal.addEventListener("click", (event) => {
      if (event.target === modal || event.target.closest(".bilhk-pwa-close")) {
        modal.classList.remove("show");
      }
    });

    document.body.appendChild(modal);
    return modal;
  }

  function showInstallHelp() {
    ensureModal().classList.add("show");
  }

  async function installApp() {
    if (isStandalone()) {
      showInstallHelp();
      return;
    }

    if (!deferredPrompt) {
      showInstallHelp();
      return;
    }

    deferredPrompt.prompt();
    try {
      await deferredPrompt.userChoice;
    } catch (error) {
      console.warn(`${APP_NAME} install prompt closed:`, error);
    }
    deferredPrompt = null;
  }

  function bindVisibleButtons() {
    document.querySelectorAll("[data-bilhk-install-app]").forEach((button) => {
      if (button.dataset.bilhkInstallBound === "1") return;
      button.dataset.bilhkInstallBound = "1";
      button.addEventListener("click", installApp);
    });
  }

  function createFloatingButton() {
    if (floatingButton || isStandalone() || !document.body) return;
    ensureStyles();

    floatingButton = document.createElement("button");
    floatingButton.type = "button";
    floatingButton.className = "bilhk-pwa-floating-install";
    floatingButton.setAttribute("aria-label", "Installera BILHK som app");
    floatingButton.setAttribute("data-bilhk-install-app", "");
    floatingButton.innerHTML = '<i class="fa-solid fa-download"></i><span>Installera app</span>';
    floatingButton.addEventListener("click", installApp);
    document.body.appendChild(floatingButton);
  }

  function setupInstallUI() {
    if (isStandalone()) return;
    bindVisibleButtons();
    createFloatingButton();
  }

  function registerServiceWorker() {
    if (!("serviceWorker" in navigator)) return;

    window.addEventListener("load", () => {
      navigator.serviceWorker
        .register(SERVICE_WORKER_URL)
        .then((registration) => {
          registration.update().catch(() => undefined);
          console.log(`${APP_NAME} service worker registered.`);
        })
        .catch((error) => {
          console.warn(`${APP_NAME} service worker registration failed:`, error);
        });
    });
  }

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredPrompt = event;
    setupInstallUI();
  });

  window.addEventListener("appinstalled", () => {
    deferredPrompt = null;
    if (floatingButton) floatingButton.remove();
    floatingButton = null;
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", setupInstallUI);
  } else {
    setupInstallUI();
  }

  registerServiceWorker();
  window.BILHKInstallApp = installApp;
})();
